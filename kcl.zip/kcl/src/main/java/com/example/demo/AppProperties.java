package com.example.demo;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import lombok.Data;
import software.amazon.awssdk.regions.Region;


@Data
@ConfigurationProperties(prefix = "app")
@Validated
public class AppProperties {

	private String streamName;

	private Region Region;

}
